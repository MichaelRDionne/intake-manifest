# Intake notes

Synthetic example. No real data.
